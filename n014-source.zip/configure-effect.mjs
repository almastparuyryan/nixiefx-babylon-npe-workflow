import { readFile, writeFile } from "node:fs/promises";

const path = "vfx-project/particle-data/effects/impact-burst.json";
const effect = JSON.parse(await readFile(path, "utf8"));
effect.targetProfile = "portable";
const emitter = effect.emitters[0];

emitter.loop = false;
emitter.duration = 0.8;
emitter.maxParticles = 48;
emitter.spawn.rate = 0;
emitter.spawn.rateValue.value = 0;
emitter.spawn.rateValue.min = 0;
emitter.spawn.rateValue.max = 0;
emitter.spawn.rateValue.curve.forEach((point) => { point.y = 0; });
emitter.spawn.rateValue.curveB.forEach((point) => { point.y = 0; });
emitter.spawn.bursts = [{
  time: 0,
  count: 24,
  cycles: 1,
  interval: 0.1,
  probability: 1
}];
emitter.spawn.shape = "sphere";
emitter.spawn.radius = 0.1;
emitter.spawn.radiusValue.value = 0.1;
emitter.spawn.radiusValue.min = 0.1;
emitter.spawn.radiusValue.max = 0.1;
emitter.spawn.radiusValue.curve.forEach((point) => { point.y = 0.1; });
emitter.spawn.radiusValue.curveB.forEach((point) => { point.y = 0.1; });
emitter.modules.velocity = true;
emitter.initializeParticle.velocity.mode = "shapeDirection";
emitter.initializeParticle.velocity.speed.value = 4;
emitter.initializeParticle.velocity.speed.min = 4;
emitter.initializeParticle.velocity.speed.max = 4;
emitter.initializeParticle.velocity.speed.curve.forEach((point) => { point.y = 4; });
emitter.initializeParticle.velocity.speed.curveB.forEach((point) => { point.y = 4; });
emitter.initializeParticle.lifetime.value = 0.7;
emitter.initializeParticle.lifetime.min = 0.7;
emitter.initializeParticle.lifetime.max = 0.7;
emitter.initializeParticle.lifetime.curve.forEach((point) => { point.y = 0.7; });
emitter.initializeParticle.lifetime.curveB.forEach((point) => { point.y = 0.7; });
emitter.initializeParticle.color.color = [1, 0.55, 0.08, 1];
emitter.initializeParticle.color.colorB = [1, 0.55, 0.08, 1];
emitter.billboard.sizeStart = 0.05;
emitter.billboard.sizeEnd = 0.05;
emitter.billboard.sizeValue.value = 0.05;
emitter.billboard.sizeValue.min = 0.05;
emitter.billboard.sizeValue.max = 0.05;
emitter.billboard.sizeValue.curve.forEach((point) => { point.y = 0.05; });
emitter.billboard.sizeValue.curveB.forEach((point) => { point.y = 0.05; });

await writeFile(path, `${JSON.stringify(effect, null, 2)}\n`);
