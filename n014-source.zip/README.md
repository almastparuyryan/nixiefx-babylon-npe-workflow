# N-014: NixieFX and Babylon.js NPE comparison asset

This folder contains a runnable, side-by-side **workflow** example and a draft Hashnode article in `ARTICLE.md`. It is not a performance test or a claim that one authored effect runs in both engines.

## Reproduce

```sh
npm ci
./node_modules/.bin/nixie-fx validate ./vfx-project
npm run dev
```

Open the URL printed by Vite. Press **Replay NixieFX burst** to trigger the orange one-shot effect and **Save observed screenshot** to save both canvases. The Babylon example is the public Node Particle Editor snippet `#8O4BJ2`, loaded through Babylon's snippet service. The page uses the pinned Babylon 9.27.1 UMD build from jsDelivr. Network access to both services is required.

The NixieFX source is `vfx-project/particle-data/effects/impact-burst.json`; the already exported runtime files are in `public/vfx`. Regenerate them after editing the source:

```sh
./node_modules/.bin/nixie-fx export ./vfx-project
cp -R vfx-project/out/vfx/. public/vfx/
```

## Verified on October 5, 2026

- NixieFX validation: zero errors, zero warnings, two informational notes about PixiJS depth semantics.
- Vite production build: succeeded.
- Local browser: both previews rendered, replay produced the orange burst, and the capture control saved `nixiefx-vs-babylon-npe.png`.
- No frame-rate or memory measurements were taken. The Babylon effect is an official example, not a translated version of the NixieFX effect.

N-014 is **not published**. The signed-in Hashnode account has a Wagglet-focused publication and requires Pro to create a second publication; this NixieFX comparison should not be posted under the unrelated publication merely to satisfy a link target.

Source for the Babylon snippet and CPU/NPE description: <https://forum.babylonjs.com/t/new-feature-the-node-particle-editor-npe/59303>. NixieFX runtime reference: <https://nixiefx.com/vfx-runtime-docs/>.
