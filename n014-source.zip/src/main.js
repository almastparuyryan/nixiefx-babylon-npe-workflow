import './style.css';
import { Application } from 'pixi.js';
import { loadVfxExportBundle } from 'nixie-fx/export';
import { PixiVfxRenderer, createPixiVfx2dProjection } from 'nixie-fx/pixi';

const pixiStage = document.querySelector('#pixi-stage');
const babylonStage = document.querySelector('#babylon-stage');
const replay = document.querySelector('#replay');
const capture = document.querySelector('#capture');
const status = document.querySelector('#status');

async function getJSON(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Could not load ${url}: ${response.status}`);
  return response.json();
}

async function start() {
  const manifest = await getJSON('/vfx/manifest.json');
  const effectsByPath = Object.fromEntries(await Promise.all(
    manifest.effects.map(async ({ path }) => [path, await getJSON(`/vfx/${path}`)]),
  ));
  const bundle = loadVfxExportBundle(
    { manifest, effectsByPath },
    { requiredBackend: 'pixi2d' },
  );
  const effect = bundle.effectsById.get('impact-burst');
  if (!effect) throw new Error('NixieFX export does not contain impact-burst');

  const width = Math.max(320, Math.floor(pixiStage.clientWidth));
  const height = 360;
  const pixi = new Application();
  await pixi.init({ width, height, background: 0x101827, antialias: true, preserveDrawingBuffer: true });
  pixiStage.appendChild(pixi.canvas);
  const nixie = new PixiVfxRenderer({
    parent: pixi.stage,
    projection: createPixiVfx2dProjection({
      originX: width / 2, originY: height / 2, pixelsPerUnit: 75, yAxis: 'up',
    }),
  });
  const burst = nixie.createEffect(effect, { position: [0, 0, 0], seed: 42 });

  const BABYLON = window.BABYLON;
  if (!BABYLON?.NodeParticleSystemSet) {
    throw new Error('Babylon.js NodeParticleSystemSet is unavailable');
  }
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  babylonStage.appendChild(canvas);
  const engine = new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true });
  const scene = new BABYLON.Scene(engine);
  scene.clearColor = new BABYLON.Color4(0.063, 0.094, 0.153, 1);
  const camera = new BABYLON.ArcRotateCamera('camera', -Math.PI / 2, Math.PI / 2.4, 8,
    BABYLON.Vector3.Zero(), scene);
  camera.attachControl(canvas, true);
  new BABYLON.HemisphericLight('light', new BABYLON.Vector3(0, 1, 0), scene);

  // Babylon.js's published NPE example, not an attempted import of a NixieFX file.
  const npe = await BABYLON.NodeParticleSystemSet.ParseFromSnippetAsync('#8O4BJ2');
  const particleSet = await npe.buildAsync(scene);
  particleSet.start();

  replay.disabled = false;
  capture.disabled = false;
  replay.addEventListener('click', () => {
    burst.reset({ seed: 42 });
    burst.spawn({ seed: 42 });
  });
  capture.addEventListener('click', () => {
    const combined = document.createElement('canvas');
    combined.width = width * 2;
    combined.height = height;
    const context = combined.getContext('2d');
    context.drawImage(pixi.canvas, 0, 0);
    context.drawImage(canvas, width, 0);
    combined.toBlob((blob) => {
      if (!blob) return;
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'nixiefx-vs-babylon-npe.png';
      link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    }, 'image/png');
  });

  let previous = performance.now();
  function frame(now) {
    const dt = Math.min((now - previous) / 1000, 0.05);
    previous = now;
    nixie.update(dt);
    scene.render();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  status.textContent = 'Ready. The two effects run in separate renderers; they are not pixel-matched.';
}

start().catch((error) => {
  status.textContent = error.message;
  console.error(error);
});
