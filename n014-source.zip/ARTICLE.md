# NixieFX and Babylon.js Node Particle Editor: two runnable particle workflows

A particle tool is useful only if its output reaches the game scene you ship. To compare authoring paths, I built a small page with two independent effects: a NixieFX impact burst exported to PixiJS 8, and Babylon.js's published Node Particle Editor (NPE) example loaded from snippet `#8O4BJ2`. Both run in the same browser page, but they do **not** share an effect format or renderer. The result is a workflow comparison, not a pixel match or speed benchmark.

![Observed NixieFX burst and Babylon.js NPE effect](nixiefx-vs-babylon-npe.png)

The screenshot above came from the running page after pressing **Replay NixieFX burst** and **Save observed screenshot**. The left orange burst is the NixieFX export in PixiJS. The white effect on the right is the Babylon NPE snippet in a Babylon scene. Animation timing means a fresh capture will show a different frame.

## Reproduce the page

The source is in `day-03/n-014-demo`. With Node.js and npm installed:

```sh
npm ci
./node_modules/.bin/nixie-fx validate ./vfx-project
npm run dev
```

Open the local address printed by Vite. The checked-in `public/vfx` directory holds the exported NixieFX manifest and effect; `vfx-project` holds its editable source. To regenerate the export after changing the effect, run:

```sh
./node_modules/.bin/nixie-fx export ./vfx-project
cp -R vfx-project/out/vfx/. public/vfx/
```

The page also loads pinned `babylonjs@9.27.1` from jsDelivr and asks Babylon's snippet service for `#8O4BJ2`. Those network dependencies must be reachable. The page reports an error instead of silently showing a blank comparison when loading fails.

## NixieFX path: export, inspect, load

The NixieFX effect is an authored JSON file, then an exported runtime bundle. The browser reads `manifest.json` and effect JSON, and the loader enforces `requiredBackend: 'pixi2d'`:

```js
const bundle = loadVfxExportBundle(
  { manifest, effectsByPath },
  { requiredBackend: 'pixi2d' },
);
const effect = bundle.effectsById.get('impact-burst');
const runtime = new PixiVfxRenderer({ parent: pixi.stage, projection });
const burst = runtime.createEffect(effect, { position: [0, 0, 0], seed: 42 });
// On replay:
burst.reset({ seed: 42 });
burst.spawn({ seed: 42 });
```

The fixed seed makes the NixieFX motion repeatable. The page advances the runtime once per animation frame. This is the part a PixiJS game would attach to an actual hit or reward event. The `pixi2d` support report matters: validation reported **zero errors and zero warnings** for this source effect, plus two informational notes. PixiJS uses deterministic 2.5D draw order and depth ink for its depth settings; it does not gain a GPU depth buffer from the effect file. The [NixieFX runtime documentation](https://nixiefx.com/vfx-runtime-docs/) explains the export bundle and per-backend reports, including settings that cannot be carried unchanged into PixiJS.

## Babylon path: load a node graph into a scene

Babylon's NPE produces a `NodeParticleSystemSet`. For this page I used the public example snippet from Babylon's NPE announcement, not a hand-translated NixieFX effect:

```js
const npe = await BABYLON.NodeParticleSystemSet
  .ParseFromSnippetAsync('#8O4BJ2');
const particleSet = await npe.buildAsync(scene);
particleSet.start();
```

The Babylon scene has its own engine, camera and render loop. This path is relevant when the game already uses Babylon and the team wants to edit creation, update and rendering behavior in NPE's node graph. Babylon's published NPE guide says this system is CPU based. The page does not measure its CPU cost, and it cannot infer that cost from the screenshot.

## What the experiment actually shows

The two previews started and rendered together in a local browser on October 5, 2026. The NixieFX replay control produced the orange burst, and the capture control saved the accompanying PNG. The validation and Vite production build both succeeded. These observations establish that each side can be loaded through its documented route; they do **not** establish equivalent visual quality, frame rate, memory usage, feature parity or portability between the tools.

For a studio choosing a workflow, first choose the target runtime. A PixiJS HUD or 2D game can use the NixieFX Pixi adapter after checking the export's `pixi2d` report. A Babylon scene can load a graph authored in NPE. If the team needs the *same authored effect* in both engines, this page is not evidence of that: NixieFX ships PixiJS and Three.js adapters, while the Babylon snippet is a separate authoring system. Budget time for a deliberate port or separate effects, then compare the result on the actual devices your players use.

## Limitations before publishing a larger claim

This page uses different source effects, different renderers and external snippet/CDN services. It does not instrument draw calls or benchmark devices. A fair performance comparison would first define an equivalent visible target, particle count, texture, resolution, replay schedule and device matrix, then record frame time and memory alongside screenshots. Until that test exists, the reproducible conclusion is narrower: both authoring routes can produce a visible browser particle effect, with different integration steps and no interchange format demonstrated here.
